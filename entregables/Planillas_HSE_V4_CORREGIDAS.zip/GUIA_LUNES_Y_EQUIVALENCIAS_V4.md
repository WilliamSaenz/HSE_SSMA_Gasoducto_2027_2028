# Emisión de lunes y nombres de indicadores — versión 4

El usuario confirmó que el informe se emite cada lunes y cubre el lunes a domingo inmediatamente anterior.

## Calendario

En INICIO:

- C42: corte seleccionado; predeterminado Lunes a domingo anterior.
- C43: fecha calculada de emisión, el lunes siguiente al domingo de cierre.
- C44: fecha de emisión del informe 1. Se propone 12/10/2026, siguiendo el cierre previo 11/10/2026. Es editable para fijar la numeración real del proyecto.
- C10: número del informe. Cada incremento desplaza siete días el período y la emisión.
- C17:C18: solo se usan cuando se selecciona Corte personalizado; no reemplazan por accidente el corte estándar.

Con la base propuesta: informe 1 = 05/10 al 11/10, emisión 12/10; informe 2 = 12/10 al 18/10, emisión 19/10. La numeración del informe no se confunde con el número de semana ISO.

Las fechas anteriores de configuración 01/10 y 11/10 se conservaron en INICIO!G43:H43, columnas técnicas ocultas. Se actualizaron las referencias de inicio de semana y las etiquetas del libro. Se conservaron registros y archivos originales.

## Nombres prácticos y siglas ocultas

La nueva hoja INDICADORES presenta una columna de nombres sencillos, qué informa cada indicador, unidad, período y criterio. F:H contienen, respectivamente, sigla del formulario, equivalencia del marco y fórmula técnica. Están ocultas inicialmente.

En 1_ACCIDENTES, V:Y contienen las siglas y códigos que alimentan las fórmulas y sus equivalencias; también están ocultas. Los campos de carga usan nombres completos: Con días perdidos, Con trabajo restringido, Con tratamiento médico, Fatalidad, Primeros auxilios y Sin lesión. Tránsito usa Catastrófico, Mayor, Serio y Otro, correspondientes a C/M/S/O del PPT.

Para mostrar o esconder estas columnas, seleccionar las columnas vecinas y usar Mostrar/Ocultar columnas en Excel. Se permite dar formato a columnas en estas hojas protegidas sin desbloquear las fórmulas. No eliminar las columnas técnicas.

Los resúmenes muestran nombres prácticos; los cálculos técnicos y valores reportados mantienen su distinción. Los identificadores internos de OUT_KPI permanecen en A, ahora oculta.

| Nombre visible | Formulario | Marco / fórmula |
|---|---|---|
| Accidentes registrables por millón de horas | IFT | TRICF = (DAFWC + RWC + MTC + F) × 1.000.000 / HHT |
| Accidentes con días perdidos por millón de horas | IFA | DAFWCF = DAFWC × 1.000.000 / HHT |
| Accidentes de tránsito por millón de kilómetros | IFAT | TVCR = (C + M + S + O) × 1.000.000 / km |
| Accidentes de tránsito severos por millón de kilómetros | Sin sigla propia en el formulario | SVCR = (C + M + S) × 1.000.000 / km |
| Índice de conducta de manejo del proveedor | ICM | Valor oficial del proveedor, sin promediar escalas |
| Observaciones preventivas programadas y realizadas | OPS | Observación Preventiva de Seguridad; actividad distinta de la empresa OPS |
| Mejoras de simulacros implementadas, acumulado (%) | ICME | Implementadas acumuladas / generadas acumuladas × 100; sin generadas: No aplica |

Las equivalencias de accidentes y tránsito se verificaron en la tabla de la lámina 6 del PPT aportado. Se mantienen la meta de IFA 0 y el criterio de reporte del ducto: IFT/IFA reportados en 0, con resultados técnicos separados. IFA como nombre para DAFWCF sigue siendo la asignación del usuario, pendiente de ratificar con quien definió el formulario.

La lámina 6 distingue el tiempo de cierre de investigaciones de accidentes de los días de cierre de hallazgos de la lámina 8. Los tiempos de cierre de mejoras de simulacros de estas planillas corresponden a mejoras/hallazgos: no se rotulan como duración de investigaciones de accidentes.

No se importaron metas ilustrativas, horas estimadas, kilómetros estimados ni ejemplos numéricos del PPT como datos reales. El PPT se utilizó como referencia; no fue modificado.

## Corrección de compatibilidad Excel

Se corrigió el orden XML de autoFilter y mergeCells en la hoja de accidentes de ambos libros. La versión anterior podía ser reparada por Excel, eliminando la hoja. La corrección conserva datos, fórmulas, protecciones, imágenes y demás partes; solo cambia el orden de esos elementos. Usar los libros V4, no las copias reparadas por Excel de V3.

Se validaron las estructuras base de todas las hojas, libro, estilos y textos compartidos contra los esquemas ECMA-376, aplicando compatibilidad de marcado para metadatos de Microsoft. Esta validación no equivale a una prueba de apertura en Microsoft Excel, que no está disponible en esta máquina.
